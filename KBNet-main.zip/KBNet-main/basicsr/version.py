# GENERATED VERSION FILE
# TIME: Wed Mar  9 22:05:30 2022
__version__ = '1.2.0+10018c6'
short_version = '1.2.0'
version_info = (1, 2, 0)
